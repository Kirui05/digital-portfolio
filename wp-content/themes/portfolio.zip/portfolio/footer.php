<!-- footer section -->
<footer>
  <div class="container">
    <div class="social-icons">
      <a href="https://www.facebook.com/profile.php?id=100080778152373"><i class="fab fa-facebook-f"></i></a>
      <a href="https://twitter.com/theeboss_nick"><i class="fab fa-twitter"></i></a>
      <a href="https://www.instagram.com/theeboss_nick/"><i class="fab fa-instagram"></i></a>
      <a href="https://www.linkedin.com/in/nicholas-kirui-073231107/"><i class="fab fa-linkedin-in"></i></a>
      <a href="https://github.com/Kirui05"><i class="fab fa-github"></i></a>
    </div>
    <div class="contact-info">
      <p>Email: nicholaskirui6@gmail.com</p>
    </div>
    <div class="copyright">
      <p>&copy; 2023 Nicholas Kirui portfolio. All rights reserved.</p>
    </div>
  </div>
</footer>

</body>
</html>